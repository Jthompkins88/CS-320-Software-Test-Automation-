import java.util.Date;

public class Appointment {

    private final String appointmentID;
    private Date appointmentDate;
    private String description;

    // Creates a new appointment
    public Appointment(String appointmentID,
                       Date appointmentDate,
                       String description) {

        validateID(appointmentID);
        validateDate(appointmentDate);
        validateDescription(description);

        this.appointmentID = appointmentID;
        this.appointmentDate = new Date(
            appointmentDate.getTime());
        this.description = description;
    }

    // Checks that the appointment ID is valid
    private void validateID(String appointmentID) {
        if (appointmentID == null ||
            appointmentID.length() > 10) {

            throw new IllegalArgumentException(
                "Invalid appointment ID");
        }
    }

    // Checks that the date is not null or in the past
    private void validateDate(Date appointmentDate) {
        if (appointmentDate == null ||
            appointmentDate.before(new Date())) {

            throw new IllegalArgumentException(
                "Appointment date cannot be in the past");
        }
    }

    // Checks that the description is valid
    private void validateDescription(String description) {
        if (description == null ||
            description.length() > 50) {

            throw new IllegalArgumentException(
                "Invalid appointment description");
        }
    }

    // Returns the appointment ID
    public String getAppointmentID() {
        return appointmentID;
    }

    // Returns a copy of the appointment date
    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    // Returns the appointment description
    public String getDescription() {
        return description;
    }
}