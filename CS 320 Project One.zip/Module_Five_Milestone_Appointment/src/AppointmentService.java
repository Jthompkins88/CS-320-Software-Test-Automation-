import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    // Stores appointments using their unique IDs
    private final Map<String, Appointment> appointments =
            new HashMap<>();

    // Adds a new appointment
    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException(
                "Appointment cannot be null");
        }

        if (appointments.containsKey(
                appointment.getAppointmentID())) {

            throw new IllegalArgumentException(
                "Appointment ID already exists");
        }

        appointments.put(
            appointment.getAppointmentID(), appointment);
    }

    // Deletes an appointment using its ID
    public void deleteAppointment(String appointmentID) {

        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException(
                "Appointment not found");
        }

        appointments.remove(appointmentID);
    }

    // Finds an appointment using its ID
    public Appointment getAppointment(String appointmentID) {
        return appointments.get(appointmentID);
    }
}