import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    // Creates a future date for testing
    private Date futureDate() {
        return new Date(
            System.currentTimeMillis() + 86400000L);
    }

    // Tests adding an appointment
    @Test
    void testAddAppointment() {

        AppointmentService service =
            new AppointmentService();

        Appointment appointment = new Appointment(
            "1001", futureDate(), "Doctor appointment");

        service.addAppointment(appointment);

        assertNotNull(service.getAppointment("1001"));
        assertEquals("Doctor appointment",
            service.getAppointment("1001").getDescription());
    }

    // Tests rejecting duplicate appointment IDs
    @Test
    void testDuplicateAppointment() {

        AppointmentService service =
            new AppointmentService();

        Appointment appointment1 = new Appointment(
            "1001", futureDate(), "Doctor appointment");

        Appointment appointment2 = new Appointment(
            "1001", futureDate(), "Dentist appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class,
            () -> service.addAppointment(appointment2));
    }

    // Tests rejecting a null appointment
    @Test
    void testAddNullAppointment() {

        AppointmentService service =
            new AppointmentService();

        assertThrows(IllegalArgumentException.class,
            () -> service.addAppointment(null));
    }

    // Tests deleting an appointment
    @Test
    void testDeleteAppointment() {

        AppointmentService service =
            new AppointmentService();

        Appointment appointment = new Appointment(
            "1001", futureDate(), "Doctor appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("1001");

        assertNull(service.getAppointment("1001"));
    }

    // Tests deleting an appointment that does not exist
    @Test
    void testDeleteMissingAppointment() {

        AppointmentService service =
            new AppointmentService();

        assertThrows(IllegalArgumentException.class,
            () -> service.deleteAppointment("9999"));
    }

    // Tests adding multiple appointments
    @Test
    void testAddMultipleAppointments() {

        AppointmentService service =
            new AppointmentService();

        service.addAppointment(new Appointment(
            "1001", futureDate(), "Doctor appointment"));

        service.addAppointment(new Appointment(
            "1002", futureDate(), "Dentist appointment"));

        assertNotNull(service.getAppointment("1001"));
        assertNotNull(service.getAppointment("1002"));
    }

    // Tests retrieving an appointment
    @Test
    void testGetAppointment() {

        AppointmentService service =
            new AppointmentService();

        service.addAppointment(new Appointment(
            "1001", futureDate(), "Doctor appointment"));

        assertEquals("1001",
            service.getAppointment("1001").getAppointmentID());
    }

    // Tests looking for an appointment that does not exist
    @Test
    void testGetMissingAppointment() {

        AppointmentService service =
            new AppointmentService();

        assertNull(service.getAppointment("9999"));
    }
}