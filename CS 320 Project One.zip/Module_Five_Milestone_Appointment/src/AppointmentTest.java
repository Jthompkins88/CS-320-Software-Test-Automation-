import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    // Creates a date one day in the future
    private Date futureDate() {
        return new Date(
            System.currentTimeMillis() + 86400000L);
    }

    // Creates a date one day in the past
    private Date pastDate() {
        return new Date(
            System.currentTimeMillis() - 86400000L);
    }

    // Tests creating a valid appointment
    @Test
    void testAppointmentCreation() {

        Date date = futureDate();

        Appointment appointment = new Appointment(
            "1001", date, "Doctor appointment");

        assertEquals("1001", appointment.getAppointmentID());
        assertEquals(date, appointment.getAppointmentDate());
        assertEquals("Doctor appointment",
            appointment.getDescription());
    }

    // Appointment ID cannot be null
    @Test
    void testNullAppointmentID() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                null, futureDate(), "Doctor appointment"));
    }

    // Appointment ID cannot exceed 10 characters
    @Test
    void testLongAppointmentID() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "12345678901", futureDate(),
                "Doctor appointment"));
    }

    // Appointment date cannot be null
    @Test
    void testNullAppointmentDate() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "1001", null, "Doctor appointment"));
    }

    // Appointment date cannot be in the past
    @Test
    void testPastAppointmentDate() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "1001", pastDate(), "Doctor appointment"));
    }

    // Description cannot be null
    @Test
    void testNullDescription() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "1001", futureDate(), null));
    }

    // Description cannot exceed 50 characters
    @Test
    void testLongDescription() {

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(
                "1001", futureDate(),
                "This appointment description is too long "
                + "because it contains more than fifty characters"));
    }

    // Tests a description that is exactly 50 characters
    @Test
    void testMaximumDescriptionLength() {

        String description = "A".repeat(50);

        Appointment appointment = new Appointment(
            "1001", futureDate(), description);

        assertEquals(50,
            appointment.getDescription().length());
    }

    // Tests an appointment ID that is exactly 10 characters
    @Test
    void testMaximumIDLength() {

        Appointment appointment = new Appointment(
            "1234567890", futureDate(),
            "Doctor appointment");

        assertEquals("1234567890",
            appointment.getAppointmentID());
    }

    // Checks that changing the original date
    // does not change the appointment date
    @Test
    void testDateProtection() {

        Date date = futureDate();

        Appointment appointment = new Appointment(
            "1001", date, "Doctor appointment");

        Date originalDate = appointment.getAppointmentDate();

        date.setTime(System.currentTimeMillis() - 86400000L);

        assertEquals(originalDate,
            appointment.getAppointmentDate());
    }

    // Checks that changing the returned date
    // does not change the saved appointment date
    @Test
    void testReturnedDateProtection() {

        Appointment appointment = new Appointment(
            "1001", futureDate(), "Doctor appointment");

        Date originalDate = appointment.getAppointmentDate();
        Date returnedDate = appointment.getAppointmentDate();

        returnedDate.setTime(System.currentTimeMillis()
            - 86400000L);

        assertEquals(originalDate,
            appointment.getAppointmentDate());
    }
}