
public class Task {
	private final String taskID;
	private String name;
	private String description;
	
	public Task(String taskID, String name, String description) {
		validateTaskID(taskID);
		validateName(name);
		validateDescription(description);
		
		this.taskID = taskID;
		this.name = name;
		this.description = description;
	}
	
    // Task ID cannot be null or longer than 10 characters
    private void validateTaskID(String taskID) {
        if (taskID == null || taskID.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
    }
    
    // Task name cannot be null or longer than 20 characters
    private void validateName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
    }
    
    // Description cannot be null or longer than 50 characters
    private void validateDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
    }
    
    // Returns the task ID
    public String getTaskID() {
        return taskID;
    }
    
    // Returns the task name
    public String getName() {
        return name;
    }
    
    // Returns the description
    public String getDescription() {
        return description;
    }
    
    // Updates the task name
    public void setName(String name) {
        validateName(name);
        this.name = name;
    }
    
    // Updates the description
    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }
}