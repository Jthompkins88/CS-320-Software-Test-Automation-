import java.util.HashMap;
import java.util.Map;

public class TaskService {
	// Stores tasks using their unique IDs
    private final Map<String, Task> tasks = new HashMap<>();;
	

    // Adds a new task
    public void addTask(Task task) {

        if (task == null) {
            throw new IllegalArgumentException(
                "Task cannot be null");
        }

        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException(
                "Task ID already exists");
        }
        
        tasks.put(task.getTaskID(), task);
    }

    // Deletes a task using its ID
    public void deleteTask(String taskID) {

        if (!tasks.containsKey(taskID)) {
            throw new IllegalArgumentException(
                "Task not found");
        }

        tasks.remove(taskID);
    }
    
    //finds a task using its ID
    public Task getTask(String taskID) {
    	return tasks.get(taskID);
    }
    
    // Updates the name of an existing task
    public void updateTaskName(String taskID, String name) {

        Task task = findTask(taskID);
        task.setName(name);
    }
    
    // Updates the description of an existing task
    public void updateTaskDescription(String taskID,
                                      String description) {

        Task task = findTask(taskID);
        task.setDescription(description);
    }

    // Checks that the task exists before updating it
    private Task findTask(String taskID) {

        Task task = tasks.get(taskID);

        if (task == null) {
            throw new IllegalArgumentException(
                "Task not found");
        }

        return task;
    }
}

