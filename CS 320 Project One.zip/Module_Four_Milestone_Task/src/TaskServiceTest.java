import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // Tests adding a new task
    @Test
    void testAddTask() {

        TaskService service = new TaskService();

        Task task = new Task(
            "1001", "Homework", "Complete CS 320 assignment");

        service.addTask(task);

        assertNotNull(service.getTask("1001"));
        assertEquals("Homework",
            service.getTask("1001").getName());
    }

    // Tests rejecting duplicate task IDs
    @Test
    void testDuplicateTask() {

        TaskService service = new TaskService();

        Task task1 = new Task(
            "1001", "Homework", "Complete assignment");

        Task task2 = new Task(
            "1001", "Project", "Complete milestone");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class,
            () -> service.addTask(task2));
    }

    // Tests rejecting a null task
    @Test
    void testAddNullTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class,
            () -> service.addTask(null));
    }

    // Tests deleting an existing task
    @Test
    void testDeleteTask() {

        TaskService service = new TaskService();

        Task task = new Task(
            "1001", "Homework", "Complete assignment");

        service.addTask(task);
        service.deleteTask("1001");

        assertNull(service.getTask("1001"));
    }

    // Tests deleting a task that does not exist
    @Test
    void testDeleteMissingTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class,
            () -> service.deleteTask("9999"));
    }

    // Tests updating a task name
    @Test
    void testUpdateTaskName() {

        TaskService service = new TaskService();

        service.addTask(new Task(
            "1001", "Homework", "Complete assignment"));

        service.updateTaskName("1001", "CS Homework");

        assertEquals("CS Homework",
            service.getTask("1001").getName());
    }

    // Tests updating a task description
    @Test
    void testUpdateTaskDescription() {

        TaskService service = new TaskService();

        service.addTask(new Task(
            "1001", "Homework", "Complete assignment"));

        service.updateTaskDescription(
            "1001", "Complete Module Four milestone");

        assertEquals("Complete Module Four milestone",
            service.getTask("1001").getDescription());
    }

    // Tests updating a task that does not exist
    @Test
    void testUpdateMissingTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class,
            () -> service.updateTaskName("9999", "New Task"));
    }

    // Tests rejecting an invalid name update
    @Test
    void testInvalidNameUpdate() {

        TaskService service = new TaskService();

        service.addTask(new Task(
            "1001", "Homework", "Complete assignment"));

        assertThrows(IllegalArgumentException.class,
            () -> service.updateTaskName("1001", null));
    }

    // Tests rejecting an invalid description update
    @Test
    void testInvalidDescriptionUpdate() {

        TaskService service = new TaskService();

        service.addTask(new Task(
            "1001", "Homework", "Complete assignment"));

        assertThrows(IllegalArgumentException.class,
            () -> service.updateTaskDescription("1001", null));
    }
}
