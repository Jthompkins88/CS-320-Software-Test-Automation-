import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // Tests creating a valid task
    @Test
    void testTaskCreation() {

        Task task = new Task(
            "1001", "Homework", "Complete CS 320 assignment");

        assertEquals("1001", task.getTaskID());
        assertEquals("Homework", task.getName());
        assertEquals("Complete CS 320 assignment",
            task.getDescription());
    }

    // Task ID cannot be null
    @Test
    void testNullTaskID() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task(null, "Homework", "Complete assignment"));
    }

    // Task ID cannot exceed 10 characters
    @Test
    void testLongTaskID() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task("12345678901", "Homework",
                "Complete assignment"));
    }

    // Task name cannot be null
    @Test
    void testNullTaskName() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task("1001", null, "Complete assignment"));
    }

    // Task name cannot exceed 20 characters
    @Test
    void testLongTaskName() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task("1001", "This Task Name Is Too Long",
                "Complete assignment"));
    }

    // Description cannot be null
    @Test
    void testNullDescription() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task("1001", "Homework", null));
    }

    // Description cannot exceed 50 characters
    @Test
    void testLongDescription() {

        assertThrows(IllegalArgumentException.class, () ->
            new Task("1001", "Homework",
                "This description is too long because it has more "
                + "than fifty characters in the task description"));
    }

    // Tests updating the task name
    @Test
    void testUpdateTaskName() {

        Task task = new Task(
            "1001", "Homework", "Complete assignment");

        task.setName("CS Homework");

        assertEquals("CS Homework", task.getName());
    }

    // Tests updating the task description
    @Test
    void testUpdateDescription() {

        Task task = new Task(
            "1001", "Homework", "Complete assignment");

        task.setDescription("Complete Module Four milestone");

        assertEquals("Complete Module Four milestone",
            task.getDescription());
    }

    // Tests rejecting an invalid name update
    @Test
    void testInvalidNameUpdate() {

        Task task = new Task(
            "1001", "Homework", "Complete assignment");

        assertThrows(IllegalArgumentException.class,
            () -> task.setName(null));
    }

    // Tests rejecting an invalid description update
    @Test
    void testInvalidDescriptionUpdate() {

        Task task = new Task(
            "1001", "Homework", "Complete assignment");

        assertThrows(IllegalArgumentException.class,
            () -> task.setDescription(null));
    }
}