
public class Contact {

    private final String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Creates a contact with the required information
    public Contact(String contactID, String firstName,
                   String lastName, String phone,
                   String address) {

        validateID(contactID);
        validateName(firstName);
        validateName(lastName);
        validatePhone(phone);
        validateAddress(address);

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Contact ID cannot be null or over 10 characters
    private void validateID(String contactID) {
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException(
                "Invalid contact ID");
        }
    }

    // First and last names cannot be null or over 10 characters
    private void validateName(String name) {
        if (name == null || name.length() > 10) {
            throw new IllegalArgumentException(
                "Invalid name");
        }
    }

    // Phone number must contain exactly 10 digits
    private void validatePhone(String phone) {
        if (phone == null || !phone.matches("[0-9]{10}")) {
            throw new IllegalArgumentException(
                "Invalid phone number");
        }
    }

    // Address cannot be null or over 30 characters
    private void validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException(
                "Invalid address");
        }
    }

    // Returns contact information
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Updates the first name
    public void setFirstName(String firstName) {
        validateName(firstName);
        this.firstName = firstName;
    }

    // Updates the last name
    public void setLastName(String lastName) {
        validateName(lastName);
        this.lastName = lastName;
    }

    // Updates the phone number
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    // Updates the address
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }
}
