import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // Stores contacts using their unique IDs
    private final Map<String, Contact> contacts =
            new HashMap<>();

    // Adds a new contact
    public void addContact(Contact contact) {

        if (contact == null) {
            throw new IllegalArgumentException(
                "Contact cannot be null");
        }

        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException(
                "Contact ID already exists");
        }

        contacts.put(contact.getContactID(), contact);
    }

    // Deletes a contact using its ID
    public void deleteContact(String contactID) {

        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException(
                "Contact not found");
        }

        contacts.remove(contactID);
    }

    // Returns a contact using its ID
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    // Updates a contact's first name
    public void updateFirstName(String contactID,
                                String firstName) {

        Contact contact = findContact(contactID);
        contact.setFirstName(firstName);
    }

    // Updates a contact's last name
    public void updateLastName(String contactID,
                               String lastName) {

        Contact contact = findContact(contactID);
        contact.setLastName(lastName);
    }

    // Updates a contact's phone number
    public void updatePhone(String contactID,
                            String phone) {

        Contact contact = findContact(contactID);
        contact.setPhone(phone);
    }

    // Updates a contact's address
    public void updateAddress(String contactID,
                              String address) {

        Contact contact = findContact(contactID);
        contact.setAddress(address);
    }

    // Finds an existing contact before updating it
    private Contact findContact(String contactID) {

        Contact contact = contacts.get(contactID);

        if (contact == null) {
            throw new IllegalArgumentException(
                "Contact not found");
        }

        return contact;
    }
}
