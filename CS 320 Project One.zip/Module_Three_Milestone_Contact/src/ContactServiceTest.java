import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    // Tests adding a new contact
    @Test
    void testAddContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        service.addContact(contact);

        assertNotNull(service.getContact("1001"));
        assertEquals("James",
            service.getContact("1001").getFirstName());
    }

    // Tests rejecting duplicate contact IDs
    @Test
    void testDuplicateContact() {

        ContactService service = new ContactService();

        Contact contact1 = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        Contact contact2 = new Contact(
            "1001", "John", "Jones",
            "2035559999", "456 Oak Street");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class,
            () -> service.addContact(contact2));
    }

    // Tests rejecting a null contact
    @Test
    void testAddNullContact() {

        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class,
            () -> service.addContact(null));
    }

    // Tests deleting a contact
    @Test
    void testDeleteContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        service.addContact(contact);
        service.deleteContact("1001");

        assertNull(service.getContact("1001"));
    }

    // Tests deleting a contact that does not exist
    @Test
    void testDeleteMissingContact() {

        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class,
            () -> service.deleteContact("9999"));
    }

    // Tests updating the first name
    @Test
    void testUpdateFirstName() {

        ContactService service = new ContactService();

        service.addContact(new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street"));

        service.updateFirstName("1001", "John");

        assertEquals("John",
            service.getContact("1001").getFirstName());
    }

    // Tests updating the last name
    @Test
    void testUpdateLastName() {

        ContactService service = new ContactService();

        service.addContact(new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street"));

        service.updateLastName("1001", "Jones");

        assertEquals("Jones",
            service.getContact("1001").getLastName());
    }

    // Tests updating the phone number
    @Test
    void testUpdatePhone() {

        ContactService service = new ContactService();

        service.addContact(new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street"));

        service.updatePhone("1001", "2035559999");

        assertEquals("2035559999",
            service.getContact("1001").getPhone());
    }

    // Tests updating the address
    @Test
    void testUpdateAddress() {

        ContactService service = new ContactService();

        service.addContact(new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street"));

        service.updateAddress("1001", "456 Oak Street");

        assertEquals("456 Oak Street",
            service.getContact("1001").getAddress());
    }

    // Tests updating a contact that does not exist
    @Test
    void testUpdateMissingContact() {

        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class,
            () -> service.updateFirstName("9999", "John"));
    }

    // Tests rejecting an invalid phone update
    @Test
    void testInvalidPhoneUpdate() {

        ContactService service = new ContactService();

        service.addContact(new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street"));

        assertThrows(IllegalArgumentException.class,
            () -> service.updatePhone("1001", "12345"));
    }
}