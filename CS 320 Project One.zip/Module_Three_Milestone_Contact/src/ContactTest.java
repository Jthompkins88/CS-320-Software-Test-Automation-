import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Tests creating a valid contact
    @Test
    void testContactCreation() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        assertEquals("1001", contact.getContactID());
        assertEquals("James", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("2035551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    // Contact ID cannot be null
    @Test
    void testNullContactID() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "James", "Smith",
                "2035551234", "123 Main Street"));
    }

    // Contact ID cannot be longer than 10 characters
    @Test
    void testLongContactID() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "James", "Smith",
                "2035551234", "123 Main Street"));
    }

    // First name cannot be null
    @Test
    void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", null, "Smith",
                "2035551234", "123 Main Street"));
    }

    // First name cannot be longer than 10 characters
    @Test
    void testLongFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "Christopher", "Smith",
                "2035551234", "123 Main Street"));
    }

    // Last name cannot be null
    @Test
    void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", null,
                "2035551234", "123 Main Street"));
    }

    // Last name cannot be longer than 10 characters
    @Test
    void testLongLastName() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Washingtons",
                "2035551234", "123 Main Street"));
    }

    // Phone must be exactly 10 digits
    @Test
    void testShortPhone() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Smith",
                "203555123", "123 Main Street"));
    }

    // Phone cannot contain letters
    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Smith",
                "203555ABCD", "123 Main Street"));
    }

    // Phone cannot be null
    @Test
    void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Smith",
                null, "123 Main Street"));
    }

    // Address cannot be null
    @Test
    void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Smith",
                "2035551234", null));
    }

    // Address cannot exceed 30 characters
    @Test
    void testLongAddress() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("1001", "James", "Smith",
                "2035551234",
                "12345 Very Long Residential Street"));
    }

    // Tests updating contact information
    @Test
    void testContactUpdates() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        contact.setFirstName("John");
        contact.setLastName("Jones");
        contact.setPhone("2035559999");
        contact.setAddress("456 Oak Street");

        assertEquals("John", contact.getFirstName());
        assertEquals("Jones", contact.getLastName());
        assertEquals("2035559999", contact.getPhone());
        assertEquals("456 Oak Street", contact.getAddress());
    }

    // Rejects invalid first name updates
    @Test
    void testInvalidFirstNameUpdate() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class,
            () -> contact.setFirstName(null));
    }

    // Rejects invalid last name updates
    @Test
    void testInvalidLastNameUpdate() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class,
            () -> contact.setLastName("VeryLongLastName"));
    }

    // Rejects invalid phone updates
    @Test
    void testInvalidPhoneUpdate() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class,
            () -> contact.setPhone("123"));
    }

    // Rejects invalid address updates
    @Test
    void testInvalidAddressUpdate() {

        Contact contact = new Contact(
            "1001", "James", "Smith",
            "2035551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class,
            () -> contact.setAddress(null));
    }
}
